#include "ChannelState.h"

bool ChannelState::isIdle() {

	return idle;
}

double ChannelState::getRSSI() {

	return rssi;
}

