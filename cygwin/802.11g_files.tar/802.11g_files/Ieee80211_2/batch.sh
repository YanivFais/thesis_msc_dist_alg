#! /bin/sh
for ((i=1; $i<9; i++)); do
   ./Ieee80211  -r $i
done
