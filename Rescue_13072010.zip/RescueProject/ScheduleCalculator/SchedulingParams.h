#pragma once

class SchedulingParams
{
public:
	SchedulingParams(const char * configFileName);
	~SchedulingParams(void);

	bool   mIsValid;

	char * COMMUNICATION_GRAPH_FILENAME;
	char * INTERFERENCE_GRAPH_FILENAME;
	char * COORDS_FILENAME;
	char * REQUESTS_FILENAME;
	char * SCHEDULE_FILENAME;

	int    N_FREQS_FOR_SCHEDULE;
	int    N_TIME_SLOTS;

private:
	static const char * DEFAULT_COMMUNICATION_GRAPH_FILENAME;
	static const char * DEFAULT_INTERFERENCE_GRAPH_FILENAME;
	static const char * DEFAULT_COORDS_FILENAME;
	static const char * DEFAULT_REQUESTS_FILENAME;
	static const char * DEFAULT_SCHEDULE_FILENAME;

	static const int    DEFAULT_N_FREQS_FOR_SCHEDULE;
	static const int    DEFAULT_N_TIME_SLOTS;
};
