#ifndef AD_HOC_WI_FI_PATH_LOSS_MODEL_H_
#define AD_HOC_WI_FI_PATH_LOSS_MODEL_H_

#include "AnalogueModel.h"

class AdHocWiFiPathLossModel;

class AdHocWiFiPathLossModelMapping: public SimpleConstMapping {
protected:
	static DimensionSet dimensions;

	/** Pointer to the model to get parameters from */
	AdHocWiFiPathLossModel* model;

	double distance;

public:
	AdHocWiFiPathLossModelMapping(AdHocWiFiPathLossModel* model,
					   double distanceP,
					   const Argument& start,
					   const Argument& end):
		SimpleConstMapping(dimensions, start, end, Argument(0.01)), // last argument is interval to iterate over when calcluating attenuation
		model(model),distance(distanceP)
	{}

	virtual double getValue(const Argument& pos) const;

	/**
	 * @brief creates a clone of this mapping.
	 *
	 * This method has to be implemented by every subclass.
	 * But most time the implementation will look like the
	 * implementation of this method (except of the class name).
	 */
	ConstMapping* constClone() const
	{
		return new AdHocWiFiPathLossModelMapping(*this);
	}
};

/**
 * Implements the project path loss model PathLossModel after.
 */
class AdHocWiFiPathLossModel: public AnalogueModel {
protected:
	friend class AdHocWiFiPathLossModelMapping;

	/** @brief HostMove of this analogue models host. */
	Move* hostMove;

	double alpha,beta;


public:
	AdHocWiFiPathLossModel(Move* hostMove,double alphaP,double betaP):
		hostMove(hostMove),alpha(alphaP),beta(betaP)
	{}
	virtual ~AdHocWiFiPathLossModel() {}

	virtual void filterSignal(Signal& s);
};

#endif
