//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
//

#ifndef ADHOCWIFIMAC_H_
#define ADHOCWIFIMAC_H_

#include "Mac80211.h"

class AdHocWiFiMac: public Mac80211 {
public:
	AdHocWiFiMac();
	virtual ~AdHocWiFiMac();

	virtual void initialize(int stage);

protected:

	/** @brief Handle messages from lower layer - override to send messages with our bitrate*/
	virtual void handleLowerControl(cMessage*);

};

#endif /* ADHOCWIFIMAC_H_ */
