/* -*- mode:c++ -*- ********************************************************
 * file:        AdHocWiFiApplLayer.h
 *
 * author:      Yaniv Fais
 *
 *
 *              This program is free software; you can redistribute it
 *              and/or modify it under the terms of the GNU General Public
 *              License as published by the Free Software Foundation; either
 *              version 2 of the License, or (at your option) any later
 *              version.
 *              For further information see file COPYING
 *              in the top level directory
 ***************************************************************************
 * description: send messages with random delay and size
 * halts every interval to allow other side to move
 **************************************************************************/


#ifndef AD_HOC_WI_FI_APPL_LAYER_H
#define AD_HOC_WI_FI_APPL_LAYER_H

#include <BaseApplLayer.h>
#include <vector>
using namespace std;

/**
 * @brief Application layer to test lower layer implementations
 *
 * This application layer is very similar to the BurstApplLayer.
 * The difference is that is sends messages with different sizes and waits every interval
 * The parameters can be set in omnetpp.ini
 *
 * @sa TestApplALyer
 * @ingroup applLayer
 * @author Yaniv Fais
 **/

class AdHocWiFiMac;

class AdHocWiFiApplLayer : public BaseApplLayer
{
 public:
  /** @brief Initialize module parameters*/
  virtual void initialize(int);
  virtual void finish();

  enum AdHocWiFiApplLayerMsg {
		SEND_TEST_TIMER = LAST_BASE_APPL_MESSAGE_KIND,
  		SEND_NEW_ROUND,
  		TEST_MESSAGE,
  		LAST_AD_HOC_WI_FI_APPL_MESSAGE_KIND
      };

  static int getCurrentRound() { return g_current_round; }

  /**
   * set round start time (only if first message)
   * @param t round start time
   **/
  void setRoundStartTime(simtime_t t);

  /**
   * set round end time
   * @param t round end time
   **/
  void setRoundEndTime(simtime_t t);

 protected:
  /** @brief Handle self messages such as timer... */
  virtual void handleSelfMsg(cMessage*);

  /** @brief Handle messages from lower layer */
  virtual void handleLowerMsg(cMessage*);

  /** @brief send a test packet to connected neighbors with destination*/
  virtual void sendMessage(int dest);

  /** @brief Number of messages to send in a burst*/
  int burstSize;

  /** @brief true if sender node o.w receiver **/
  bool sender;


  ApplPkt *pkt;

  /** @brief time of round start */
  simtime_t roundStart;

  /** @brief time of round end (after all messages sent/received) **/
  simtime_t roundEnd;

  /** @brief maximal time of round (after which round switches)**/
  simtime_t roundMaxTime;

  /** @brief Number of rounds and current round number **/
  int rounds,currRound;

  /** @brief current round number as global for othr components to sync **/
  static int g_current_round;

  /** @brief number of messages for this round */
   int msgsNum;

   /** @brief rate of send/receive in rounds**/
   cOutVector roundsMsgsNum;

   /** @brief number of messages sent/receive in rounds**/
   cOutVector roundsRate;

   /** @brief time of send/receive in rounds**/
   cOutVector roundsTime;

   /** @brief average SINR in rounds**/
   cOutVector roundsAvgSINR;

   cOutVector roundsLostPackets;

   /**
    * messages used - message for round start and repeating test message
    */
  cMessage* roundMsg,*testMsg;

  /** @brief from host address to network address , used for sending outgoing messages **/
  static map<int,int> networkAddresses;
};

#endif // AD_HOC_WI_FI_APPL_LAYER_H

