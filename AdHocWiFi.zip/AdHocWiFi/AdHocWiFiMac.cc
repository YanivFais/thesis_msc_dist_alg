//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
//

#include "AdHocWiFiMac.h"
#include "AdHocWiFiApplLayer.h"
#include "NetwControlInfo.h"
#include <SimpleAddress.h>
#include "MacToPhyControlInfo.h"
#include <PhyToMacControlInfo.h>
#include <Decider80211.h>
#include <DeciderResult80211.h>

Define_Module(AdHocWiFiMac);

AdHocWiFiMac::AdHocWiFiMac() : Mac80211() {

}

AdHocWiFiMac::~AdHocWiFiMac() {

}

void AdHocWiFiMac::initialize(int stage)
{
	Mac80211::initialize(stage);
}

void  AdHocWiFiMac::handleLowerControl (cMessage * msg )
{

 // override just to store statistics of send time end
 if (msg->getKind()==MacToPhyInterface::TX_OVER) {

	cModule * nic = getParentModule();
	cModule * node = nic->getParentModule();
	cModule * app = node->getSubmodule("appl");
	AdHocWiFiApplLayer * appl = check_and_cast<AdHocWiFiApplLayer*>(app);
	appl->setRoundEndTime(simTime());
 }
 Mac80211::handleLowerControl(msg);
}
