/* -*- mode:c++ -*- ********************************************************
 * file:        AdHocWiFiApplLayer.cc
 *
 * author:      Yaniv Fais
 *
 *
 *              This program is free software; you can redistribute it
 *              and/or modify it under the terms of the GNU General Public
 *              License as published by the Free Software Foundation; either
 *              version 2 of the License, or (at your option) any later
 *              version.
 *              For further information see file COPYING
 *              in the top level directory
 ***************************************************************************
 * description: send messages with random delay and size
 * halts every interval to allow other side to move
 **************************************************************************/


#include "AdHocWiFiApplLayer.h"
#include "NetwControlInfo.h"
#include <SimpleAddress.h>
#include <AdHocWiFiDecider.h>
#include <AdHocWiFiMac.h>
#include <BaseMacLayer.h>

Define_Module(AdHocWiFiApplLayer);

// global variable
int AdHocWiFiApplLayer::g_current_round = -1;
map<int,int> AdHocWiFiApplLayer::networkAddresses;

// do some initialization
void AdHocWiFiApplLayer::initialize(int stage)
{
    currRound = -1;
	msgsNum = 0;
    BaseApplLayer::initialize(stage);

    if(stage==0){
    	sender = (myApplAddr()%2==0);
    	roundsRate.setName("rounds-rate");
    	roundsMsgsNum.setName("rounds-messages-number");
    	roundsTime.setName("rounds-time");
    	roundsAvgSINR.setName("rounds-average-SINR");
    	roundsLostPackets.setName("rounds-lost-packets");
        if(hasPar("burstSize"))
            burstSize = par("burstSize");
        else
            burstSize = 3;
        if(hasPar("rounds"))
        	rounds = par("rounds");
        else
        	rounds = 3;
        if(hasPar("roundMaxTime"))
        	roundMaxTime = par("roundMaxTime");
        else
        	roundMaxTime = 10;
    }

    if(stage == 0) {
        roundMsg = new cMessage( "new-round", SEND_NEW_ROUND );
        testMsg = new cMessage( "delay-timer", SEND_TEST_TIMER );
    }
    else if(stage==1) {
        scheduleAt(simTime(), roundMsg);
        networkAddresses[myApplAddr()] = getParentModule()->getSubmodule("net")->getId();
    }


}


void AdHocWiFiApplLayer::handleSelfMsg(cMessage *msg)
{


    switch(msg->getKind())
    {
    case SEND_TEST_TIMER:
        if (sender) {
        	for(int i=0; i<burstSize; i++)
        		sendMessage(myApplAddr()+1);
    		msgsNum+=burstSize;
        	roundStart = simTime();
        }
        break;
    case SEND_NEW_ROUND:
    	if (currRound>=0) {
    		//EV << "round-time [" << myApplAddr() << "] " << roundStart << " - " << roundEnd << endl;
    	 	roundsRate.record((msgsNum/burstSize)/(roundEnd - roundStart));
    	 	roundsMsgsNum.record(msgsNum);
    	 	roundsTime.record(roundEnd-roundStart);
    	}
    	currRound++;
    	msgsNum = 0;
    	roundStart = roundEnd = 0;
    	if (g_current_round < currRound)
    		g_current_round = currRound;
    	EV << "Switching to round " << currRound << endl;
        scheduleAt(simTime() /*+ dblrand()*/, testMsg);
        if (currRound < rounds)
        	scheduleAt(simTime() + roundMaxTime, roundMsg);
        else endSimulation();
        break;
    default:
        EV <<" Unknown self message! -> delete, kind: "<<msg->getKind()<<endl;
    }
}


/**
 * There are two kinds of messages that can arrive at this module: The
 * first (kind = BROADCAST_MESSAGE) is a broadcast packet from a
 * neighbor node to which we have to send a reply. The second (kind =
 * BROADCAST_REPLY_MESSAGE) is a reply to a broadcast packet that we
 * have send and just causes some output before it is deleted
 **/
void AdHocWiFiApplLayer::handleLowerMsg( cMessage* msg )
{
    ApplPkt *m;
    switch( msg->getKind() ){
    case TEST_MESSAGE:
        m = static_cast<ApplPkt *>(msg);
        EV << "Host["<< myApplAddr() << "] Received a packet from host["<<m->getSrcAddr()<<"] " << currRound << "-" << msgsNum << "/" << burstSize << " arrive time=" << m->getArrivalTime() << " \n";
        if (!sender) { // receiver node
        	if (m->getSrcAddr()==myApplAddr()-1) { // only for me
        		msgsNum++;
        		roundEnd = simTime();
        	}
        }
        delete msg;
        break;
    default:
	EV <<"Error! got packet with unknown kind: " << msg->getKind()<<endl;
        delete msg;
    }
}

/**
 * This function creates a new test message and sends it down to
 * the network layer
 **/
void AdHocWiFiApplLayer::sendMessage(int dest)
{
	// the dest is both L2 and L3 since app/mac use same address for simplicity
    ApplPkt *pkt = new ApplPkt("TEST_MESSAGE", TEST_MESSAGE);
    pkt->setDestAddr(dest);
    // we use the host modules getIndex() as a appl address
    pkt->setSrcAddr( myApplAddr());
    pkt->setBitLength(headerLength);

    // set the control info to tell the network layer the layer 3
    // address;
    pkt->setControlInfo( new NetwControlInfo(networkAddresses[dest] /*L3BROADCAST*/) );

   // EV << "Sending test packet to application " << dest << " and " << networkAddresses[dest] << endl;
    sendDown( pkt );
}


void AdHocWiFiApplLayer::setRoundStartTime(simtime_t t)
{
	if (msgsNum==0 && roundStart==0 &&!sender)
		roundStart = t;
}

void AdHocWiFiApplLayer::setRoundEndTime(simtime_t t)
{
		roundEnd = t;
}

void AdHocWiFiApplLayer::finish()
{
	BaseApplLayer::finish();
	cancelAndDelete(testMsg);
	testMsg = NULL;
	cancelAndDelete(roundMsg);
	roundMsg = NULL;

	//EV << "Node:" << myApplAddr() <<  endl;
	string type;
	AdHocWiFiDecider::RoundsCollection * roundsSINRs = NULL;
	if (!sender) {
		type = " Received = ";
		roundsSINRs = AdHocWiFiDecider::getRoundsSINRs(myApplAddr()-1,myApplAddr());
	}
	else type = " sent = ";
	vector<int> roundsLostPacketsVec = AdHocWiFiDecider::getRoundsLostPackets();
	for (int r=0;r<rounds;r++) {
		roundsLostPackets.recordWithTimestamp(roundMaxTime*(r+1),roundsLostPacketsVec[r]);
		//EV << "Round = " << r << type;
		double SINR = 0;
		if (roundsSINRs) {
			if ((*roundsSINRs).size()>(unsigned)r) {
				// calculate average SINR from all packets between these nodes
				AdHocWiFiDecider::SINRcollection::const_iterator sIter;
				AdHocWiFiDecider::SINRcollection * SINRs = (*roundsSINRs)[r] ;
				for (sIter = SINRs->begin(); sIter != SINRs->end(); sIter++)
					SINR += *sIter;
				SINR/= SINRs->size();
				//EV << " <SINR>=" << SINR;
				delete SINRs;
				(*roundsSINRs)[r] = NULL;
			}
			roundsAvgSINR.recordWithTimestamp(roundMaxTime*(r+1),SINR);
		}
		//EV << endl;
	}
	if (roundsSINRs)
		delete roundsSINRs;
}
