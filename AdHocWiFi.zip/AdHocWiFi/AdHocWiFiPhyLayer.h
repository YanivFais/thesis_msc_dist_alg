/*
 * AdHocWiFiPhyLayer.h
 *
 *      Author: Yaniv Fais
 */

#ifndef AD_HOC_WI_FI_PHYLAYER_H_
#define AD_HOC_WI_FI_PHYLAYER_H_

#include <PhyLayer.h>
#include "AdHocWiFiPathLossModel.h"

class AdHocWiFiPhyLayer: public PhyLayer {
protected:

	virtual void handleMessage(cMessage* msg);

	virtual AnalogueModel* getAnalogueModelFromName(std::string name, ParameterMap& params);

	virtual Decider* getDeciderFromName(std::string name, ParameterMap& params);
};

#endif
