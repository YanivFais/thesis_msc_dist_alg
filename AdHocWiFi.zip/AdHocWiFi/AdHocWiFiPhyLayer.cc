/*
 * AdHocWiFiPhyLayer.cc
 *
 */

#include "AdHocWiFiPhyLayer.h"
#include "AdHocWiFiDecider.h"
#include "AdHocWiFiApplLayer.h"

Define_Module(AdHocWiFiPhyLayer);

AnalogueModel* AdHocWiFiPhyLayer::getAnalogueModelFromName(std::string name, ParameterMap& params)
{

	if(name == "AdHocWiFiPathLossModel")
	{
		double alpha = params["alpha"].doubleValue();
		double beta = params["beta"].doubleValue();

		return new AdHocWiFiPathLossModel(&move, alpha , beta);
	}

	return PhyLayer::getAnalogueModelFromName(name, params);
}

Decider* AdHocWiFiPhyLayer::getDeciderFromName(std::string name, ParameterMap& params) {

	if(name == "AdHocWiFiDecider"){
		double threshold = params["threshold"];
		double centerFreq = params["centerFrequency"];
		double payloadBerThreshold = params["payloadBerThreshold"];
		const char * p = params["phyOpMode"];
		const char * c = params["channelModel"];
		const char * m = params["deciderMode"];
		string phyOpModeStr = p;
		string channelModelStr = c;
		string deciderModeStr = m;
		AdHocWiFiDecider::DeciderMode deciderMode = AdHocWiFiDecider::Default;
		if (deciderModeStr=="Mixim")
			deciderMode = AdHocWiFiDecider::Default;
		else if (deciderModeStr=="Sorin")
			deciderMode = AdHocWiFiDecider::Sorin;
		else if (deciderModeStr=="Moti")
			deciderMode = AdHocWiFiDecider::Moti;
		else EV << "Decider mode not recognized " << deciderMode << ", using default Mixim" << endl;
		char phyOpMode = (phyOpModeStr=="g" ? 'g' : 'b');
		char channelModel = (channelModelStr=="r" ? 'r' : 'a');
		return new AdHocWiFiDecider(this, threshold, sensitivity, centerFreq, findHost()->getIndex(),
				coreDebug,phyOpMode,channelModel,deciderMode,payloadBerThreshold);
	}
	return PhyLayer::getDeciderFromName(name,params);
}

void AdHocWiFiPhyLayer::handleMessage(cMessage* msg)
{
	if(msg->getKind() == AIR_FRAME) {
		AirFrame* frame = static_cast<AirFrame*>(msg);

		if (frame->getState()==START_RECEIVE) {
			cModule * nic = getParentModule();
			cModule * node = nic->getParentModule();
			cModule * app = node->getSubmodule("appl");
			AdHocWiFiApplLayer * appl = check_and_cast<AdHocWiFiApplLayer*>(app);
			appl->setRoundStartTime(simTime());
		}
	}
	BasePhyLayer::handleMessage(msg);
}

