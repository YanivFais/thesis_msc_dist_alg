#include "AdHocWiFiPathLossModel.h"

void AdHocWiFiPathLossModel::filterSignal(Signal& s)
{
	simtime_t start = s.getSignalStart();
	simtime_t end = start + s.getSignalLength();

	const Move& senderMove = s.getMove();
	// assuming our host/sender don't move
	double distance = senderMove.startPos.distance(hostMove->startPos);

	//add a new AdHocWiFiPathLossModelMapping to the signals attenuation list
	s.addAttenuation(new AdHocWiFiPathLossModelMapping(this,distance,
											  Argument(start),
											  Argument(end)));
//  add another model ? -	s.addAttenuation(...);
}


DimensionSet AdHocWiFiPathLossModelMapping::dimensions(Dimension::time);

double AdHocWiFiPathLossModelMapping::getValue(const Argument& pos) const {

	// implementing Path Loss Model as is appendix A according to the formula:
	// Pb = \alpha * (Tr_b / (d_AB ^ \beta))
	// We need to compute attenuation which is a gain factor over the TX (Tr_b)
	// In order to compute  Pb , this is \alpha / (d_AB^\beta)

	long double d_AB_pow_b = pow(distance,model->beta);
	long double att = model->alpha / (d_AB_pow_b);

	// coreEV << __FUNCTION__ << " distance :" << distance << "; att=" << att << " Alpha=" << model->alpha << " Beta = " << model->beta << endl;

	return att;
}
